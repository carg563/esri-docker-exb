import { TemplateType } from '../type';
export declare const headerTemplates: {
    name: string;
    type: TemplateType;
    icon: any;
    config: any;
}[];

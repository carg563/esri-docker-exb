import { TemplateType } from '../type';
export declare const footerTemplates: {
    name: string;
    type: TemplateType;
    icon: any;
    config: any;
}[];

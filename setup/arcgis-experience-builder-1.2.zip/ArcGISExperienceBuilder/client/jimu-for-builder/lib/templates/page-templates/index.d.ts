import { TemplateType, Template } from '../type';
export declare const fullScreenPageTemplates: Template[];
export declare const autoScrollPageTemplates: {
    name: string;
    type: TemplateType;
    icon: any;
}[];

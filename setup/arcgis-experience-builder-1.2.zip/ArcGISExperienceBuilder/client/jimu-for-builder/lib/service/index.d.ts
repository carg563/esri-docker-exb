import * as appServices from './app-service';
import * as restServices from './rest-service';
import * as userServices from './user-service';
export { appServices, restServices, userServices };

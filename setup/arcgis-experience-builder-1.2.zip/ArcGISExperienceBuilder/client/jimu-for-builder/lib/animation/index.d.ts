import { AnimationMetaInfo } from 'jimu-core';
export declare const animationInfos: AnimationMetaInfo[];
export declare const oneByOneAnimationInfos: AnimationMetaInfo[];

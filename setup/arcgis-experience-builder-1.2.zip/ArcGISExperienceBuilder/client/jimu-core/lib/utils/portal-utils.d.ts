import { AppInfo } from '../types/app-info';
export declare function initPortalSelf(portalUrl: string): Promise<any>;
export declare function getAppInfo(appId?: string): Promise<AppInfo>;

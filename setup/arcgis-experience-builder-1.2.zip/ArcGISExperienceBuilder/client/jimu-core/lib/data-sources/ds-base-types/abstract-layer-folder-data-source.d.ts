/// <reference types="seamless-immutable" />
import { IMDataSourceJson, Immutable, ServiceDefinition } from 'jimu-core';
import { DataSource, DataSourceConstructorOptions } from '../data-source-interface';
import { AbstractSetDataSource } from './abstract-set-data-source';
/**
 * Layer from ArcGIS JS API, which may contain sublayers.
 */
export declare type FolderLayer = __esri.MapImageLayer | __esri.TileLayer | __esri.GroupLayer | __esri.Sublayer;
export interface LayerFolderDataSourceConstructorOptions extends DataSourceConstructorOptions {
    layer?: FolderLayer;
}
/**
 * Data source which contains multiple layers, like a layer folder,
 * please see {@link SupportedLayerServiceTypes} to find supported layer service types.
 */
export declare abstract class AbstractLayerFolderDataSource extends AbstractSetDataSource {
    private serviceDefinition;
    layer?: FolderLayer;
    constructor(options: LayerFolderDataSourceConstructorOptions);
    ready(): Promise<DataSource[]>;
    getServiceDefinition(): ServiceDefinition;
    protected _createChildDataSources(): Promise<DataSource[]>;
    private _loadLayer;
    fetchSchema(): Promise<Immutable.ImmutableObject<import("jimu-core").DataSourceSchema>>;
    fetchServiceDefinition(): Promise<ServiceDefinition>;
    getSubLayers(): (__esri.Sublayer | __esri.Layer)[];
    getOriginalDataId(): string | number;
    protected _getWhetherLayerIsSupported(layer: __esri.Layer | __esri.Sublayer, layerDefinition: ServiceDefinition): boolean;
    protected _fetchLayerDefinitionFromSubLayer(subLayer: __esri.Sublayer | __esri.Layer): Promise<ServiceDefinition>;
    protected _getDsJsonsFromSupportedLayers(res: {
        def: ServiceDefinition;
        url?: string;
        layer?: __esri.Layer | __esri.Sublayer;
    }[], dsJsonInConfig: IMDataSourceJson): {
        dsJson: IMDataSourceJson;
        layer?: __esri.Sublayer | __esri.Layer;
    }[];
    protected _getDsJsonsFromSingleLayerDefinition(url: string, layerDefinition: ServiceDefinition, dsJsonInConfig: IMDataSourceJson): IMDataSourceJson[];
    protected _getDsJsonsFromSingleLayer(layer: __esri.Layer | __esri.Sublayer, dsJsonInConfig: IMDataSourceJson): IMDataSourceJson[];
}

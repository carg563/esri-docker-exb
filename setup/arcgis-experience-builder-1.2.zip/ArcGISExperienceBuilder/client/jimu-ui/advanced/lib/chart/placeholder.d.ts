/// <reference types="react" />
export declare const Placeholder: ({ icon, message }: {
    icon: any;
    message: any;
}) => JSX.Element;

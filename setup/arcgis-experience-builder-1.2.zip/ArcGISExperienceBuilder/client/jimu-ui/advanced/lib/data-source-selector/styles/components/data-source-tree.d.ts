import { SerializedStyles } from 'jimu-core';
export declare function dataSourceTreeStyles(props: any): SerializedStyles;

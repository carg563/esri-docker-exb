import { SerializedStyles } from 'jimu-core';
export declare function dataSourceErrorItemStyles(props: any): SerializedStyles;

import { SerializedStyles } from 'jimu-core';
export declare function dataViewSettingPopupStyles(props: any): SerializedStyles;

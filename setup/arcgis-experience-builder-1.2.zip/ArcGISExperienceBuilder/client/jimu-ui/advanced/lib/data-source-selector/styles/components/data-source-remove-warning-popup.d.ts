import { SerializedStyles } from 'jimu-core';
export declare function dataSourceRemoveWarningPopupStyles(props: any): SerializedStyles;

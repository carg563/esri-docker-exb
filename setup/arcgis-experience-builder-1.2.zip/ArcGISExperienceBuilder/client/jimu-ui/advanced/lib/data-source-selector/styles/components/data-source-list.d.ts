import { SerializedStyles } from 'jimu-core';
export declare function dataSourceListStyles(props: any): SerializedStyles;

export declare function zoomTo(view: __esri.View, target: any, options: any): Promise<any>;

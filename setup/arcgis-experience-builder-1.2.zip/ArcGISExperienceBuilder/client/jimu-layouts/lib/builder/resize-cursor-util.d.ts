export declare function getCursor(rotation: number, initAngle: number): "nwse-resize" | "nesw-resize" | "ew-resize" | "ns-resize";

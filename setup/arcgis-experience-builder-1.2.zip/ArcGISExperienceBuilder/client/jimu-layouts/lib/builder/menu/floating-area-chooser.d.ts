/// <reference types="react" />
/** @jsx jsx */
import { React } from 'jimu-core';
export declare const FloatingAreaChooser: React.ComponentType<any>;

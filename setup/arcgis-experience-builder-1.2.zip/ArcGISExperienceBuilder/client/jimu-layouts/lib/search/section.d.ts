import { IMState } from 'jimu-core';
import { SectionProps } from '../types';
export declare function getSectionInfo(state: IMState, sectionId: string): SectionProps;

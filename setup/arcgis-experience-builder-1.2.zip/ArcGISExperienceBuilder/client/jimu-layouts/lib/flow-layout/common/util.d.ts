import { BrowserSizeMode } from 'jimu-core';
export declare function updateScreenHeight(mainPanelContainer: HTMLElement, sidePanelContainer: HTMLElement, browserSizeMode: BrowserSizeMode): void;

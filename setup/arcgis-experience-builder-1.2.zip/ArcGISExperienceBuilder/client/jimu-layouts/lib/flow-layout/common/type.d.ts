export declare const SCREEN_RATIO_IN_SMALL_SIZE = 0.33;

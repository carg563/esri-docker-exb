/// <reference types="react" />
/** @jsx jsx */
import { React, ScreenTransitionType, ImmutableArray } from 'jimu-core';
import type { LayoutProps } from 'jimu-layouts/layout-runtime';
export interface Props {
    pageId: string;
    activeIndex: number;
    viewHeight?: number;
    screens: ImmutableArray<string>;
    isSmallSize: boolean;
    transitionType: ScreenTransitionType;
    layoutEntry: React.ComponentType<LayoutProps>;
}
export declare const DEFAULT_HEADER_HEIGHT = 75;
export declare function ScreenMainPanelList(props: Props): JSX.Element;

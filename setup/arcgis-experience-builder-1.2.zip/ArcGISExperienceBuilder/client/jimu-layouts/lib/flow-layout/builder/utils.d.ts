import { LayoutInfo } from 'jimu-core';
import { Template } from 'jimu-for-builder/templates';
export declare function addTemplateRow(layoutId: string, layoutItemId: string, layoutTemplate: Template): Promise<LayoutInfo>;
export declare function addTemplateScreenGroup(layoutId: string, layoutItemId: string, screenGroupTemplate: Template): Promise<LayoutInfo>;

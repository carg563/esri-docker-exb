/**
 *
 * @param ref
 * @param rootElement
 * @param onIntersectionChange
 */
export declare function useViewportIntersection(ref: HTMLElement, watchViewportVisibility: boolean): boolean;

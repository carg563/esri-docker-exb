import { ArcGISServerInfo, ServiceDefinition } from 'jimu-core';
import { IQueryFeaturesResponse } from '@esri/arcgis-rest-feature-layer';

export interface MockQuery{
  url: string;
  result: IQueryFeaturesResponse,
  delay?: number;
}
export interface MockFeatureServiceData{
  url: string;
  serverInfo: ArcGISServerInfo;
  serviceDefinition: ServiceDefinition;
  queries?: MockQuery[]
}

export function mockFeatureService(mockData: MockFeatureServiceData){
  const serverInfoUrl = `${mockData.url.split(/\/rest(\/admin)?\/services\//)[0]}/rest/info?f=json`;

  fetchMock.mockResponse(req => {
    const reqUrl = decodeURIComponent(req.url);
    if (reqUrl === serverInfoUrl) {
      return Promise.resolve(JSON.stringify(mockData.serverInfo))
    } else if (reqUrl.split('?')[0] === mockData.url) {
      return Promise.resolve(JSON.stringify(mockData.serviceDefinition)); // schema
    } else{
      const query = mockData.queries && mockData.queries.find(q => decodeURIComponent(q.url) === reqUrl);
      if(query){
        if(query.delay){
          return new Promise(resolve => {
            setTimeout(() => {
              return resolve(JSON.stringify(query.result));
            }, query.delay)
          })
        }else{
          return Promise.resolve(JSON.stringify(query.result));
        }
      }else{
        console.log(`${reqUrl} is not mocked.`);
        return Promise.resolve({status: 404});
      }
    }
  })
}


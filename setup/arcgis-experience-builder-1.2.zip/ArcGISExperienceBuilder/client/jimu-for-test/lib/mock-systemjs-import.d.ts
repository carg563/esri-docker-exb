export declare function mockSystemJsImport(): void;

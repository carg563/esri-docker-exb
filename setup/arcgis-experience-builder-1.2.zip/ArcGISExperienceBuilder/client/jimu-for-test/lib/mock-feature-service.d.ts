import { ArcGISServerInfo, ServiceDefinition } from 'jimu-core';
import { IQueryFeaturesResponse } from '@esri/arcgis-rest-feature-layer';
export interface MockQuery {
    url: string;
    result: IQueryFeaturesResponse;
    delay?: number;
}
export interface MockFeatureServiceData {
    url: string;
    serverInfo: ArcGISServerInfo;
    serviceDefinition: ServiceDefinition;
    queries?: MockQuery[];
}
export declare function mockFeatureService(mockData: MockFeatureServiceData): void;

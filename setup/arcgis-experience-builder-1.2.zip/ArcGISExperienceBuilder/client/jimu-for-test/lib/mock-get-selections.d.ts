export declare const getSelections: (global: any) => void;

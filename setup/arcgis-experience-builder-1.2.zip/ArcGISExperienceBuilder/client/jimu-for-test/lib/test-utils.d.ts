/// <reference types="react" />
/// <reference types="cheerio" />
import { RenderOptions } from '@testing-library/react';
import { React, ThemeVariables, IMState } from 'jimu-core';
import { Store } from 'redux';
export declare const ThemeIntlWrapper: (theme: ThemeVariables, locale: string, messages: {
    [x: string]: string;
}) => ({ children }: {
    children: any;
}) => JSX.Element;
export declare const ThemeWrapper: (theme: ThemeVariables) => ({ children }: {
    children: any;
}) => JSX.Element;
export declare const IntlWrapper: (locale: string, messages: {
    [x: string]: string;
}) => ({ children }: {
    children: any;
}) => JSX.Element;
export declare const StoreWrapper: (store: Store<IMState>) => ({ children }: {
    children: any;
}) => JSX.Element;
export declare const StoreIntlWrapper: (store: Store<IMState>, locale: string, messages: {
    [x: string]: string;
}) => ({ children }: {
    children: any;
}) => JSX.Element;
export declare const StoreThemeIntlWrapper: (store: Store<IMState>, theme: ThemeVariables, locale: string, messages: {
    [x: string]: string;
}) => ({ children }: {
    children: any;
}) => JSX.Element;
export declare const withThemeIntlRender: (theme?: ThemeVariables, locale?: string, messages?: {}) => (ui: any, options?: RenderOptions) => import("@testing-library/react").RenderResult<typeof import("@testing-library/dom/types/queries")>;
export declare const withThemeRender: (theme?: ThemeVariables) => (ui: any, options?: RenderOptions) => import("@testing-library/react").RenderResult<typeof import("@testing-library/dom/types/queries")>;
export declare const withIntlRender: (locale?: string, messages?: {}) => (ui: any, options?: RenderOptions) => import("@testing-library/react").RenderResult<typeof import("@testing-library/dom/types/queries")>;
export declare const withStoreRender: (store?: Store<IMState>) => (ui: any, options?: RenderOptions) => import("@testing-library/react").RenderResult<typeof import("@testing-library/dom/types/queries")>;
export declare const withStoreIntlRender: (store?: Store<IMState>, locale?: string, messages?: {}) => (ui: any, options?: RenderOptions) => import("@testing-library/react").RenderResult<typeof import("@testing-library/dom/types/queries")>;
export declare const withStoreThemeIntlRender: (store?: Store<IMState>, theme?: ThemeVariables, locale?: string, messages?: {}) => (ui: any, options?: RenderOptions) => import("@testing-library/react").RenderResult<typeof import("@testing-library/dom/types/queries")>;
export declare const widgetRender: (store?: Store<IMState>, theme?: ThemeVariables, locale?: string, messages?: {}) => (ui: any, options?: RenderOptions) => import("@testing-library/react").RenderResult<typeof import("@testing-library/dom/types/queries")>;
export declare const mountWithStoreEnzyme: (store: Store<IMState>, children: any) => import("enzyme").ReactWrapper<any, Readonly<{}>, React.Component<{}, {}, any>>;
export declare const renderWithStoreEnzyme: (store: Store<IMState>, children: any) => Cheerio;
export declare const runFuncAsync: (timeout?: number, useFakeTimers?: boolean) => (callback: any, ...args: any[]) => Promise<unknown>;

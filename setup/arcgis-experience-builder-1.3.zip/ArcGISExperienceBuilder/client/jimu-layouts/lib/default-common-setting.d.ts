import { CommonLayoutSetting } from './types';
export declare const DEFAULT_LAYOUT_ITEM_SETTING: CommonLayoutSetting;

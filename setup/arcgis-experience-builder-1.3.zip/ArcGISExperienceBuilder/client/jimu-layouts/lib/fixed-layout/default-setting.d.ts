import { FixedLayoutSetting, FixedLayoutItemSetting } from '../types';
export declare const DEFAULT_FIX_LAYOUT_SETTING: FixedLayoutSetting;
export declare const DEFAULT_FIX_LAYOUT_ITEM_SETTING: FixedLayoutItemSetting;

export declare function loadMessage(): Promise<any>;

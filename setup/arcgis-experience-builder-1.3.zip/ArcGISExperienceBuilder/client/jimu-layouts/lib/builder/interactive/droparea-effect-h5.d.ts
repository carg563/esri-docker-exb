/// <reference types="react" />
import { React } from 'jimu-core';
import { DropAreaContext } from './droparea-common';
export declare function initH5(elem: HTMLElement, contextRef: React.RefObject<DropAreaContext>): void;

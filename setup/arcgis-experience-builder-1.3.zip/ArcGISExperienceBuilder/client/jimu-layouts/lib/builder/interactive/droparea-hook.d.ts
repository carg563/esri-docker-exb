/// <reference types="react" />
import { DropAreaProps } from './droparea-common';
export declare function DropArea(props: DropAreaProps): JSX.Element;

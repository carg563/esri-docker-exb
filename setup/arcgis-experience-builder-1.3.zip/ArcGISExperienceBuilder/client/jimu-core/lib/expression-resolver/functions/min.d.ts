import { ExpressionPart } from '../../types/expression';
import { RepeatedDataSource } from '../../repeat-data-source-context';
export declare function min(parts: ExpressionPart[], repeatedDataSource: RepeatedDataSource | RepeatedDataSource[]): Promise<number>;

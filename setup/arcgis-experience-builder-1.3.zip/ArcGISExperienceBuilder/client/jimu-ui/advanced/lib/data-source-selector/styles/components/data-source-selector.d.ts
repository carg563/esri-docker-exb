import { SerializedStyles } from 'jimu-core';
export declare function dataSourceSelectorStyles(props: any): SerializedStyles;

import { SerializedStyles } from 'jimu-core';
export declare function dataSourceItemStyles(props: any): SerializedStyles;

import { SerializedStyles } from 'jimu-core';
export declare function fieldSelectorStyles(props: any): SerializedStyles;

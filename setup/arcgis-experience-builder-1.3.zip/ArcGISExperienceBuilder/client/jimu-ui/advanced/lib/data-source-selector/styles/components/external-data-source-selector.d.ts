import { SerializedStyles } from 'jimu-core';
export declare function externalDataSourceSelectorStyles(props: any): SerializedStyles;

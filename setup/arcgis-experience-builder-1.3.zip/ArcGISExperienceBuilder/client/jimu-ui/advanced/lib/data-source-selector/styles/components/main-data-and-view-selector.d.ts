import { SerializedStyles } from 'jimu-core';
export declare function mainDataAndViewSelectorStyles(props: any): SerializedStyles;

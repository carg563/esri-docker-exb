import { Template } from '../type';
export declare const dialogTemplates: Template[];

import { IParams } from '@esri/arcgis-rest-request';
export declare function getUserContent(requestOptions: IParams): Promise<any>;

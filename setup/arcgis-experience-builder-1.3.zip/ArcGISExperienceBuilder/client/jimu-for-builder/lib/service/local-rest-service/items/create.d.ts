import { ICreateItemOptions, ICreateItemResponse } from '@esri/arcgis-rest-portal';
export declare function createItem(requestOptions: ICreateItemOptions): Promise<ICreateItemResponse>;

export declare function loadI18nMessage(): Promise<any>;

import { ArcGISDataSourceFactory } from './lib/data-sources';
export default ArcGISDataSourceFactory;
export * from './lib/data-sources';

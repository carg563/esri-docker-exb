import { ExpressionPartGoup } from '../../types/expression';
import { RepeatedDataSource } from '../../repeat-data-source-context';
export declare function average(parts: ExpressionPartGoup[], repeatedDataSource: RepeatedDataSource | RepeatedDataSource[]): Promise<number>;

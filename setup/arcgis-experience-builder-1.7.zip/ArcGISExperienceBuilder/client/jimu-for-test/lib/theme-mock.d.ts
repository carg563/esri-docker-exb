import { IMThemeVariables } from 'jimu-core';
declare const MockTheme: IMThemeVariables;
export default MockTheme;

/// <reference types="react" />
export declare const MockNumericInput: (props: any) => JSX.Element;

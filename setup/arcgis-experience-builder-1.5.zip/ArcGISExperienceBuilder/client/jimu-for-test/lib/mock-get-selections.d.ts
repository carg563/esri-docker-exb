/**
 * Get [selection](https://developer.mozilla.org/en-US/docs/Web/API/Selection) of document.
 */
export declare const mockGetSelection: (global: any) => void;

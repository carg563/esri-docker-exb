import { ToolItemConfig, SectionProps } from 'jimu-layouts/layout-runtime';
export declare function findActiveViewId(props: SectionProps): string;
export declare const sectionMenuItems: ToolItemConfig[];

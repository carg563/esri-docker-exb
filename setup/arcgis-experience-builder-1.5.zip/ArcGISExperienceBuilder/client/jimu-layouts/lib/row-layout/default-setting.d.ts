import { RowLayoutSetting, RowLayoutItemSetting } from '../types';
export declare const DEFAULT_ROW_LAYOUT_SETTING: RowLayoutSetting;
export declare const DEFAULT_ROW_ITEM_SETTING: RowLayoutItemSetting;

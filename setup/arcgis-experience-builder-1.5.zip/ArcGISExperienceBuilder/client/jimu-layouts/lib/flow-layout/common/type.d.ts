export declare const SCREEN_RATIO_IN_SMALL_SIZE = 0.33;
export declare const DEFAULT_HEADER_HEIGHT = 75;

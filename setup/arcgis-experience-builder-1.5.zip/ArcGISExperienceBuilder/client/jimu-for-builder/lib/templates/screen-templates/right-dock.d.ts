import { TemplateType } from '../type';
export declare const rightDock: {
    type: TemplateType;
    screenId: string;
    icon: any;
    config: any;
};

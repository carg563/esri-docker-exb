import { TemplateType } from '../type';
export declare const stream: {
    name: string;
    type: TemplateType;
    screenGroupId: string;
    icon: any;
    gifIcon: string;
    config: any;
};

/// <reference types="react" />
export declare function LoadingHandler(props: any): JSX.Element;

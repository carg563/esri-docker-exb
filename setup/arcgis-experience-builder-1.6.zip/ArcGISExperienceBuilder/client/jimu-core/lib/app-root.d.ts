/// <reference types="react" />
export default function AppRoot(): JSX.Element;

declare const getKeyEventName: (event: any) => string;
export default getKeyEventName;

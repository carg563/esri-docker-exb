/// <reference types="react" />
export declare const INTERACTIVE_CLASS = "jimu-interactive-node";
export declare function isKeyboardMode(): boolean;
export declare function FocusVisibility(props: any): JSX.Element;

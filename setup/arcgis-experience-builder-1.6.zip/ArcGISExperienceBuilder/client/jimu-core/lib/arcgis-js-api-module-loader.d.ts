export declare function loadArcGISJSAPIModules(modules: string[]): Promise<any[]>;
export declare function loadArcGISJSAPIModule(module: string): Promise<any>;

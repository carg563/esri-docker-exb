export declare enum StatisticType {
    Count = "count",
    Sum = "sum",
    Min = "min",
    Max = "max",
    Avg = "avg"
}
export declare const ESRIOBJECTIDTYPE = "esriFieldTypeOID";

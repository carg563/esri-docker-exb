/** Mock SystemJS.import() */
export declare function mockSystemJsImport(): void;

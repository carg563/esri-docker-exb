import { ThemeVariables } from 'jimu-core';
declare const _default: ThemeVariables;
export default _default;

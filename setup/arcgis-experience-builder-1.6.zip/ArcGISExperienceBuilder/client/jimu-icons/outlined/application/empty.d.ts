/// <reference types="react" />
import { SVGIconProps } from 'jimu-ui';
export declare const EmptyOutlined: (props: SVGIconProps) => JSX.Element;

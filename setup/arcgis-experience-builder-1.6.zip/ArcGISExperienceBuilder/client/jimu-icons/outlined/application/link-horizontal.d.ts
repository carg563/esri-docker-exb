/// <reference types="react" />
import { SVGIconProps } from 'jimu-ui';
export declare const LinkHorizontalOutlined: (props: SVGIconProps) => JSX.Element;

/// <reference types="react" />
import { SVGIconProps } from 'jimu-ui';
export declare const InvisibleOutlined: (props: SVGIconProps) => JSX.Element;

/// <reference types="react" />
import { SVGIconProps } from 'jimu-ui';
export declare const ClickOutlined: (props: SVGIconProps) => JSX.Element;

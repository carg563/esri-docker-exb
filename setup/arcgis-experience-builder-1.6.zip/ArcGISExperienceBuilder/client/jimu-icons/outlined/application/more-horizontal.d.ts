/// <reference types="react" />
import { SVGIconProps } from 'jimu-ui';
export declare const MoreHorizontalOutlined: (props: SVGIconProps) => JSX.Element;

/// <reference types="react" />
import { SVGIconProps } from 'jimu-ui';
export declare const LivingAtlasOutlined: (props: SVGIconProps) => JSX.Element;

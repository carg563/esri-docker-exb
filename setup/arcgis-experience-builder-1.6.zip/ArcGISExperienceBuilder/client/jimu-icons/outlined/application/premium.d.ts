/// <reference types="react" />
import { SVGIconProps } from 'jimu-ui';
export declare const PremiumOutlined: (props: SVGIconProps) => JSX.Element;

/// <reference types="react" />
import { SVGIconProps } from 'jimu-ui';
export declare const CheckOutlined: (props: SVGIconProps) => JSX.Element;

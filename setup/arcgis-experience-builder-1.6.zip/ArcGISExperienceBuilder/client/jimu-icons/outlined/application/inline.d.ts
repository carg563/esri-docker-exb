/// <reference types="react" />
import { SVGIconProps } from 'jimu-ui';
export declare const InlineOutlined: (props: SVGIconProps) => JSX.Element;

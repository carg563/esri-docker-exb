/// <reference types="react" />
import { SVGIconProps } from 'jimu-ui';
export declare const WarningCircleFilled: (props: SVGIconProps) => JSX.Element;

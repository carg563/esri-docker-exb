/// <reference types="react" />
import { SVGIconProps } from 'jimu-ui';
export declare const LayerFilled: (props: SVGIconProps) => JSX.Element;

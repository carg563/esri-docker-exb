/// <reference types="react" />
import { SVGIconProps } from 'jimu-ui';
export declare const SquareBorderRoundedFilled: (props: SVGIconProps) => JSX.Element;

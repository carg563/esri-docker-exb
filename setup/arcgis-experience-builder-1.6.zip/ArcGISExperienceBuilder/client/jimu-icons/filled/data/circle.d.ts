/// <reference types="react" />
import { SVGIconProps } from 'jimu-ui';
export declare const CircleFilled: (props: SVGIconProps) => JSX.Element;

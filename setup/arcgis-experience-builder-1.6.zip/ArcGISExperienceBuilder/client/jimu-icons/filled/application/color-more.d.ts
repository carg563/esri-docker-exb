/// <reference types="react" />
import { SVGIconProps } from 'jimu-ui';
export declare const ColorMoreFilled: (props: SVGIconProps) => JSX.Element;

/// <reference types="react" />
import { SVGIconProps } from 'jimu-ui';
export declare const LeftFilled: (props: SVGIconProps) => JSX.Element;

/// <reference types="react" />
import { SVGIconProps } from 'jimu-ui';
export declare const DownFilled: (props: SVGIconProps) => JSX.Element;

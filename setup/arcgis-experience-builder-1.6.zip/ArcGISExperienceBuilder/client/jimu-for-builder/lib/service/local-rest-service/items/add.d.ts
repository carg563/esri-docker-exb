import { IItemResourceOptions, IItemResourceResponse } from './helpers';
export declare function addItemResource(requestOptions: IItemResourceOptions): Promise<IItemResourceResponse>;

import { IParams } from '@esri/arcgis-rest-request';
export declare function itemsgroups(requestOptions: IParams): Promise<any>;

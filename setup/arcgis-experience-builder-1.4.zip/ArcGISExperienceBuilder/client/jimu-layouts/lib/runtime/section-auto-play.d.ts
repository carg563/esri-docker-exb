interface Props {
    sectionId: string;
    autoPlay: boolean;
    interval: number;
    loop: boolean;
}
export declare function useAutoPlay(props: Props): void;
export {};

/** @jsx jsx */
import { ReactRedux } from 'jimu-core';
import { LayoutProps } from 'jimu-layouts/layout-runtime';
declare const _default: ReactRedux.ConnectedComponent<any, Pick<unknown, never> & LayoutProps>;
export default _default;

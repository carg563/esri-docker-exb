import { ToolbarConfig } from '../../types';
export declare const fixedItemMenu: ToolbarConfig;

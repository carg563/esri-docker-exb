import { ColumnLayoutSetting } from '../types';
export declare const DEFAULT_COLUMN_LAYOUT_SETTING: ColumnLayoutSetting;

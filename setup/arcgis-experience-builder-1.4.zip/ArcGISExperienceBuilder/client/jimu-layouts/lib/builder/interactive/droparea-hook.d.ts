/** @jsx jsx */
import { jsx } from 'jimu-core';
import { DropAreaProps } from './droparea-common';
export declare function DropArea(props: DropAreaProps): jsx.JSX.Element;

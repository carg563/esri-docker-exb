import { AnimationType } from 'jimu-core';
export declare function useVisibility(effectType: AnimationType, pageId: string): boolean;

import { FlowLayoutSetting, FlowLayoutItemSetting } from '../types';
export declare const DEFAULT_FLOW_SETTING: FlowLayoutSetting;
export declare const DEFAULT_FLOW_ITEM_SETTING: FlowLayoutItemSetting;

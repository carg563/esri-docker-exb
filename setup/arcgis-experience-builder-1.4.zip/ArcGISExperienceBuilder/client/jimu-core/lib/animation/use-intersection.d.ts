export declare function useIntersection(ref: HTMLElement, monitor: boolean, rootElement?: HTMLElement): boolean;

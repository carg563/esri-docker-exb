import { DataRecord } from '../data-sources/data-source-interface';
export declare function arcgisToGeoJSON(dataRecords: DataRecord[], idAttribute: string): any;

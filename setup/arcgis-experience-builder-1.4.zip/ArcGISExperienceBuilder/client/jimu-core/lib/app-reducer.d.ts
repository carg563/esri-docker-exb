import { ActionTypes } from './app-actions';
import { IMState } from './types/state';
export default function rootReducer(state: IMState, action: ActionTypes): IMState;

import * as React from 'react';
interface State {
    appConfigLoaded: boolean;
}
export default class AppRoot extends React.PureComponent<unknown, State> {
    myEmotionCache: any;
    constructor(props: any);
    render(): JSX.Element;
}
export {};

export declare function formatValue(value: any, type: string): string;

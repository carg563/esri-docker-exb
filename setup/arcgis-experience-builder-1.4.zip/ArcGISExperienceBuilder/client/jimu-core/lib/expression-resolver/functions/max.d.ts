import { ExpressionPart } from '../../types/expression';
import { RepeatedDataSource } from '../../repeat-data-source-context';
export declare function max(parts: ExpressionPart[], repeatedDataSource: RepeatedDataSource | RepeatedDataSource[]): Promise<number>;

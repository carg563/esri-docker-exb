import { TemplateType } from '../type';
export declare const slideshow: {
    name: string;
    type: TemplateType;
    screenGroupId: string;
    icon: any;
    gifIcon: string;
    config: any;
};

export declare const screenGroupTemplates: {
    name: string;
    type: import("..").TemplateType;
    screenGroupId: string;
    icon: any;
    gifIcon: string;
    config: any;
}[];

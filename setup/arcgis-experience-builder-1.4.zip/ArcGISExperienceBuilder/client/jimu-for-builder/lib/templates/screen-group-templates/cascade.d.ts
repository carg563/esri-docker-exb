import { TemplateType } from '../type';
export declare const cascade: {
    name: string;
    type: TemplateType;
    screenGroupId: string;
    icon: any;
    gifIcon: string;
    config: any;
};

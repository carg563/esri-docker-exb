import { TemplateType } from '../type';
export declare const centralFloating: {
    type: TemplateType;
    screenId: string;
    icon: any;
    config: any;
};

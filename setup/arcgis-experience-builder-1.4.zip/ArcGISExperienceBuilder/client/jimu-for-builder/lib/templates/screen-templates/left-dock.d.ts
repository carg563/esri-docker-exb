import { TemplateType } from '../type';
export declare const leftDock: {
    type: TemplateType;
    screenId: string;
    icon: any;
    config: any;
};

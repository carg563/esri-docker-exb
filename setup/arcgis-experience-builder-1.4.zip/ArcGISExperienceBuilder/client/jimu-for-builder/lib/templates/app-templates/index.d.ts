import { Template } from '../type';
export declare const appTemplates: Template[];
